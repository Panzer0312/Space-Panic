﻿#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "game.h"
#include "resourceManager.h"

#include <iostream>

//changes the window resolution if a new monitor is dis/connected
void monitor_callback(GLFWmonitor* monitor, int event);

// The Width of the screen
const unsigned int SCREEN_WIDTH = 1080;
// The height of the screen
const unsigned int SCREEN_HEIGHT = 920;


Game SpacePanic(SCREEN_WIDTH, SCREEN_HEIGHT);
//the core function to run this game
int main(int argc, char* argv[])
{
	GLFWwindow *window;

	//init glfw library
	if (!glfwInit()) {
		return -1;
	}

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);

	//create windowed mode window
	window = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Space Panic", NULL,NULL);
	
	if (!window) {
		glfwTerminate();
		return -1;
	}

	//make windwo's context current
	glfwMakeContextCurrent(window);
	glewInit();

	// OpenGL configuration
	glfwSetMonitorCallback(monitor_callback);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// initialize game
	SpacePanic.Init();

	// deltaTime variables
	float deltaTime = 0.0f;
	float lastFrame = 0.0f;

	//loop until user closes the window
	while (!glfwWindowShouldClose(window)) {
		glClearColor(0.2f, 0.3f, 0.3f, 0.5f);
		glClear(GL_COLOR_BUFFER_BIT);
		// calculate delta time
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		
		// manage user input
		SpacePanic.ProcessInput(deltaTime,window);

		// update game state
		SpacePanic.Update(deltaTime);

		// render OpenGL
		SpacePanic.Render();

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// delete all resources as loaded using the resource manager
	ResourceManager::Clear();

	glfwTerminate();
	return 0;
}

//changes the window resolution if a new monitor is dis/connected
void monitor_callback(GLFWmonitor* monitor, int event)
{
	if (event == GLFW_CONNECTED)
	{
		// The monitor is connected
		float xscale, yscale;
		glfwGetMonitorContentScale(monitor, &xscale, &yscale);
		glViewport(0, 0, SCREEN_WIDTH * xscale+100, SCREEN_HEIGHT * yscale+100);
	}
	else if (event == GLFW_DISCONNECTED)
	{
		// The monitor is disconnected
	}
}