#pragma once
#include "game.h"
#include <stdio.h>
#include "texture.h"
class Player
{
public:
	void Init();
};

