#include "player.h"



void Player::Init()
{
	printf("Initialise Player\n");
	
}
