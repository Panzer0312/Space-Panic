#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <map>
#include <string>

#include "texture.h"

class ResourceManager
{
public:
    // resource storage
    static std::map<std::string, Texture2D> Textures;
    // loads (and generates) a texture from file
    static Texture2D GetTexture(std::string name);
    static Texture2D LoadTexture(const char* file, std::string name);
    ResourceManager();
    static void Clear();
    static void initShader();
    static unsigned int getShaderProgram();
    static unsigned int* getShaderObjects();
private:
    // loads a single texture from file
    static Texture2D loadDDSTextureFromFile(const char* file);
 
};